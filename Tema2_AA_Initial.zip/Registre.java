class Registre {
    public static void main(String[] args) {
    }
}