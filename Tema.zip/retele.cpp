#include <bits/stdc++.h>
#include "task.h"
using namespace std;

const int maxn = 1e3;
const string oracleInputFile = "sat.cnf";

class Task1 : public Task {
    public:
        int n, m, k;
        int matrix[maxn][maxn];
        void solve() {
            read_problem_data();
            formulate_oracle_question();
            ask_oracle();
            cout << "Alex e barosan\n";
            decipher_oracle_answer();
            write_answer();
        }
        void read_problem_data() {
            cin >> n >> m >> k;
            for (int i = 1; i <= m; ++i) {
                int x, y;
                cin >> x >> y;
                matrix[x][y] = matrix[y][x] = 1;
            }

        }
        void formulate_oracle_question() {
            ofstream out (oracleInputFile);
            out << "p cnf " << k * n << " ";
            int clause = k;
            out << clause << '\n';

            for (int i = 1; i <= k; ++i) {
                for (int j = 1; j <= n; ++j) {
                    out << (i - 1) * n + j << " ";
                }
                out << "0\n";
            }

            // for (int i = 1; i <= n; ++i) {
            //     for (int j = i + 1; j <= n; ++j) {
            //         if (!matrix[i][j]) {

            //             for (int t = 1; t < k; ++t) {
            //                 for (int t1 = t + 1; t <= k; ++t) {
            //                     out << -((t - 1) * n + i) << " " << -((t1 - 1) * n + j) << " 0\n";
            //                 }
            //             }

            //         }
            //     }
            // }

            // for (int i = 1; i <= k; ++i) {
            //     for (int j = i + 1; j <= k; ++j) {
            //         for (int t = 1; t <= n; ++t) {
            //             out << -((i - 1) * n + t) << " " << -((j - 1) * n + t) << " 0\n";
            //         }
            //     }
            // }

            // for (int i = 1; i <= k; ++i) {
            //     for (int j = 1; j <= n; ++j) {
            //         for (int t = j + 1; t <= n; ++t) {
            //             out << -((i - 1) * n + j) << " " << -((i - 1) * n + t) << " 0\n";
            //         }
            //     }
            // }
            out.close();

        }
        void decipher_oracle_answer() {
            
        }
        void write_answer() {
           
        }
};



int main() {
    
    Task1 retele;
    retele.solve();



    return 0;
}