#include <iostream>
using namespace std;

int main() {
    cout << "Alex";
    return 0;
}